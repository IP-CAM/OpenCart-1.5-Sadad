<?php
// Heading
$_['heading_title']         = ' Sadad Secure Payment';

// Text
$_['text_payment']          = 'Payment';
$_['text_sadad']          = '<a href="https://www.paytabs.com/" taget="_blank"><img src="https://www.paytabs.com/theme/frontend_v2/img/logo_blue.png" height="30px" width="110px" alt="Paytabs" title="Paytabs" style="border: 1px solid #EEEEEE;" /></a>';

$_['text_success']          = 'Success: You have modified Sadad Payment module!';
$_['text_paytabs_invoice']   = '<img src="https://www.paytabs.com/theme/frontend_v2/img/logo_blue.png" height="30px" width="110px"  alt="Paytabs Payment" title="Paytabs" style="border: 1px solid #EEEEEE;"/> Paytabs Payment</a>';
$_['text_live']             = 'Live';
$_['text_beta']             = 'Beta';


?>
